//
//  ViewController.swift
//  vdoCipher
//
//  Created by Ravi Prakash Pandey on 05/02/23.
//

import UIKit
import Foundation

class ViewController: UIViewController {

    var dict = [String:String]()
    //var MaxNumberOfRequestAtAtime:Int = 3
    let semaphore = DispatchSemaphore(value: 3)
    let queue = DispatchQueue.global(qos: .background)
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func clickMeForAPI(_ sender: Any) {
        ApiFecthig(apiUrl: String(Int.random(in: 0...500)))
        //ApiFecthig(apiUrl: "abc")
    }
    

}

extension ViewController {
    func ApiFecthig(apiUrl:String) {
        let baseUrl = "https://screeningtest.vdocipher.com/do-long-compute/?query="
        let fullUrl = baseUrl+apiUrl
        let url = URL(string: fullUrl)
        var request = URLRequest(url: url!)
        
        request.httpMethod = "POST"
       
        if (dict[fullUrl] == nil) {
            queue.async {
                //here if there will be more than MaxNumberOfRequestAtAtime request, then it willwait for some time until it will get signal from other response
                //wait maintains a queue and decrements each times 
               self.semaphore.wait()
                print("it's \(apiUrl) request")
                let sesssion = URLSession.shared.dataTask(with: request) { data, respose, error in
                    if error != nil {
                        print("getting error and error = \(error)")
                        return
                    }
                    if data != nil {
                        print("getting data and data = \(data)")
                        print(String(decoding: data!, as: UTF8.self))
                        self.dict[fullUrl] = String(decoding: data!, as: UTF8.self)
                    }
                    if respose != nil {
                        
                    }
                    self.semaphore.signal()
                    //print("got response of \(apiUrl) request")
                }.resume()
                
            }
        } else {
            print("Response is already in cache and response = \(dict[fullUrl])")
        }
    }
}
